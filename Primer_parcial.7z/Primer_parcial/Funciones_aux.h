void limpiarPantalla(void);
int ingresoNumero(void);
int verificarCadena(char [51]);
void formateoCadenas(char* );
int verificarTarjeta(char []);
int devolverHorasEstadia();
int validacionPatente(char []);

