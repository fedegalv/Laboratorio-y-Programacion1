
void cargarVector(int[],int);
void mostrarVector(int[],int );
void inicializarVector(int[], int);
int sumarValores(int[],int );

