int saludar(void);
int dividir(int numero);
int esDistitoCero(int numero);
int factorial(int);
int cambiarValor(int valor);
int cambiarValorReferencia(int* valor);
int dividirPorDiferencia(int datoUno, int datoDos, float* respuesta);
int esUnNumero(char* cadena);
