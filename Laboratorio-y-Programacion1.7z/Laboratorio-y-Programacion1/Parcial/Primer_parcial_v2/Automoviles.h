#ifndef automoviles_H_INCLUDED
#define automoviles_H_INCLUDED
typedef struct
{
    int idPropietario;
    char patente[51];
    int marca;
    int estado;

}sAutomovil;

void inicializarAutosEstado(sAutomovil [], int );






















#endif // automoviles_H_INCLUDED
