#ifndef propietarios_H_INCLUDED
#define propietarios_H_INCLUDED
typedef struct
{

}sPropietario;



























#endif // propietarios_H_INCLUDED
