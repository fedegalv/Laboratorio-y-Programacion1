#include "Biblioteca.h"

int mostrar(int c)
{
    printf("Hola mundo %d\n", c);
    c+=10;
    return c;
}

int mostrarDOS(int c)
{
    printf("CHAU %d\n", c);
    c+=10000;
    return c;
}
