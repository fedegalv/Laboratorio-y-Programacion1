#include "Usuarios.h"
#include "Series.h"

int buscarPorId(eUsuario [] , int ,int );
