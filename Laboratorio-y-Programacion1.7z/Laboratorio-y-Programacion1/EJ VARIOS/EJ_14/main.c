#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    for(i=3; i<100; i=i+3)
    {
        printf("%d\n",i);
    }
    return 0;
}
