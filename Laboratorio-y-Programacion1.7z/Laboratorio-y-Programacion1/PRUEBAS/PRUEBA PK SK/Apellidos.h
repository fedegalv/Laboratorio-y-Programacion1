
typedef struct
{
    int idApellido;
    char apellido[50];
    int estado;
}eApellido;

void initSurnameState(eApellido [], int );
void initSurnamesHardCoded(eApellido [], int );
void showSurnameList(eApellido [],int );
