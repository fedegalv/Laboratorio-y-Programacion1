#ifndef INFORMES_H
#define INFORMES_H

#include "CLIENTES.h"
#include "PRODUCTOS.h"
void showListaClientes(sCliente [], int , ePublicacion  [], int ,int );
int cantidadAvisosActivos(ePublicacion[], int,int );

#endif

