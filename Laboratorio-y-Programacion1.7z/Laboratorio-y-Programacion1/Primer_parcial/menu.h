int altaPropietarios(sPropietario listaPropietarios[],int tam, int* cantProp);
void menuModificar(sPropietario listaPropietarios[], int, int);
int menuBajaPropietarios(sPropietario listaPropietarios[],sAutomovil listaAutomoviles[], int, int, int);
void menuMostrarListaOrdenada(sPropietario listaPropietarios[],int ,int );
int menuAltaVehiculos(sPropietario listaPropietarios[], sAutomovil listaAutomoviles[], int , int );
void menuBajaVehiculos(sPropietario listaPropietarios[], sAutomovil listaAutomoviles[],int , int);
void menuListaAutomoviles(sAutomovil listaAutomoviles[], int);
